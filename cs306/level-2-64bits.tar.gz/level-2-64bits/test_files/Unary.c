main()
{
	int a = 2, b = 4, c = 3;

	a = a + -b * -c / -a;
	
	float d;
	
	d = --c;
}
