main()
{
	int a = 3;
	int f = 2, g = 8;

	a = a + f - g;
}
