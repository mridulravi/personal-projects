main()
{
	int a = 3;
	float b;

	b = a;
	a = b;
}
