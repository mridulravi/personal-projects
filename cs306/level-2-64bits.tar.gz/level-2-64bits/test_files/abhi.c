main()
{
	float a;
	int b;
	b = 10;
	a = b;
	return;
}
