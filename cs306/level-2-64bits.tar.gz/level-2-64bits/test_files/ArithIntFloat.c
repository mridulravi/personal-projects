main()
{
	int a = 2;
	float b = 3.4, c;

	c = a + b / a;
}
