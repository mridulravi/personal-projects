main()
{
	int a;
	float b;
	float c;

	a = 3;
	b = 2.4;
	c = 3;
}
