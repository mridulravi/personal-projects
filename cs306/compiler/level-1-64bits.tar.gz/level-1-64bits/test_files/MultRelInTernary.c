main()
{
	int a = 3;
	int b = 10;
	int c = 2;
	int d = 1;
	int e = 4;
	int f = 8;
	int g = 11;

	a = b > c ? d > e : f >= g;
}
