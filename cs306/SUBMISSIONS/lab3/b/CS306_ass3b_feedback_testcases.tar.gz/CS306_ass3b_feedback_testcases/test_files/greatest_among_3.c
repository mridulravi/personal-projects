main()
{	
	float a = 1;
	float b = 2;
	float c = 3;
	float g;

	if (a>=b && a>=c) g=a;
	if (b>=a && b>=c) g=b;
	if (c>=a && c>=b) g=c;			
			
			
}
