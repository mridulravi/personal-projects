main()
{
	float a=10.3;
	while(a<=12){
		a=a+0.5;
	}
}

