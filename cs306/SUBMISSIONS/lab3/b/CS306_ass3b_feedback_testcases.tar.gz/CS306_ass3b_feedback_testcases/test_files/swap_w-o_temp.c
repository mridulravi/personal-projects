	
main()
{
float a=6,b=3;

a=a-b;
b=a+b;
a=b-a;
}
