main()
{
	float a=10.1;
	int i=0;
	for(;i<10;i++){
		a=a+0.3;
	}
}

