main()
{
float f1=10.3;
int i1=10, i2=11;
int a, b, c, d;
float e, f, g, h;

a = i1 < f1 < i2;
b = i1 <= f1 <= i2;
c = i1 > f1 > i2;
d = i1 >= f1 >= i2;
e = i1 + f1 + i2;
f = i1 - f1 - i2;
g = i1 / f1 / i2;
h = i1 * f1 * i2;
}
