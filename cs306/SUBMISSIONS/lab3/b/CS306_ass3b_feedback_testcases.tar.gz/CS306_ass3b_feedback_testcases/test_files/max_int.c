main()
{
	int a;
	int b;
	a=2147483647; 
	b=a*2;
}
