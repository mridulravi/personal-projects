main()
{
int i1=2, i2=3;
i1 = -(-i2);
}
