main()
{
int i1=1, i2=2;
i1 = -i1-i2;
}
