main()
{
	int a=10,b=5,c=9;
	a=-(a>-b+c)/(a<=a);
}
