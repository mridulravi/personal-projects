
main()
{
	float f=5,b=1;
do{

b=b*f;
f=f-1;	
}while(f>0);

}
