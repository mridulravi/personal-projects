main()
{
	float a=5.0;
	int b=6;
	b=a;
	a=b;
}
