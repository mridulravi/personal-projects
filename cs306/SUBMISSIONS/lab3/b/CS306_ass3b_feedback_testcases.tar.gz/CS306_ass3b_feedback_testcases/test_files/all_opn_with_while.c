
main()
{
	int i=1,a=5,b=6,d=7;

do{

i=i+1;
d=a+b;
d=a-b;
d=a/b;
d=a*b;
	
}while(i<6);

}
