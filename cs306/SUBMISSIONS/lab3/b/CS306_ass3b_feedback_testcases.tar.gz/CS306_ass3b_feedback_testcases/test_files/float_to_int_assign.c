main()
{
	float a=10.567;
	
	int a1=10;
	a1=a;
	
	
}
