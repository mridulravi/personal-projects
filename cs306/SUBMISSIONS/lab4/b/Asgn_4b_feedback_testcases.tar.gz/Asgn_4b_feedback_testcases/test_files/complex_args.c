int f1(int a)
{
return 2*a+3+(3*3)*(1==1);
}

main()
{
int a=1;
int b = f1(2*a+3+(3*3*a)*(1==1));
}
