int f1(int a)
{
return a;
}



main()
{
float x = f1(3);

}
