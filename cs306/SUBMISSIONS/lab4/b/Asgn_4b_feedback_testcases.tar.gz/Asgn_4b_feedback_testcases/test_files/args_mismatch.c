void f1(int a, float b)
{
return;
}

main()
{
f1(3.4, 4);
}
