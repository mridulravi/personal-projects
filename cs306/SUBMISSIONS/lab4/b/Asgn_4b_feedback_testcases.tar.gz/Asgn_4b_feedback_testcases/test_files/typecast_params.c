void fn(int c, float d)
{
	c = 4;
}

main()
{
	int a = 3;
	int b = 5;

	fn(a,b);
}


