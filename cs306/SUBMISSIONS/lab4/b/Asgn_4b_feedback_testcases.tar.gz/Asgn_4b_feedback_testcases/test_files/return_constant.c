int fn(int c, float d)
{
	return 5;
}

main()
{
	int a = 3;
	int b = 5;
	int c;
	c = fn(a,b);
}


