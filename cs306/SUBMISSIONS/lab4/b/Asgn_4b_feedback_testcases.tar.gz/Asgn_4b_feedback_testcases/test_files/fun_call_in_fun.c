float add(float,float);
float sub(float,float);


int main()
{
	float a=2.5,b=3.3,d,e,f;	
	float c;
	c=add(a,b);
	
return 0;
}

float add (float a1,float b1)
{
	int d=sub(a1,b1);
	return (a1+b1);
}

float sub (float a1,float b1)
{
	return a1-b1;
}
