main()
{
	int a = 3;
	int b;
	b = f();

}

int f()
{
	int a;
	a = 9;
	return a;
}
