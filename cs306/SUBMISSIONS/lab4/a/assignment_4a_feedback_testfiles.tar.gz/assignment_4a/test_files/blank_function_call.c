void fun2()
{
}


void fun1()
{
fun2();
}

void fun()
{
fun1();
}

main()
{
fun();
}
