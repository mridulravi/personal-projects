int a;
main()
{
	int a;
	a=1;
	a=f(a);
	
}

int f(int c)
{
	a=5;
	return c;
}
