int i;
int fun();

int main()
{
    g();
    while(i)
    {
        fun();
        main();
    }
    return 0;
}
int fun()
{
    
}
int g()
{
	i=10;
}
