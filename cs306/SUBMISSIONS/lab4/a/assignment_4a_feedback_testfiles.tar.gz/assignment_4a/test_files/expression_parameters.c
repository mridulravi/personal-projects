void fn(int c, float d)
{
	c = 4;
}

main()
{
	int a = 3;
	float b = 5;

	fn(a,b+a);
}


