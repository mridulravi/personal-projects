main()
{
	float x;
	float y;
	float z;
	int p;
	x=8;
	y=9.1101*100;

	p=32;
	
	z=x+y-p*x;
	p=y/x/z;
}
