main()
{
int i1, i2, i3, i4;
float f1, f2, f3, f4;
i1 = f1==i1;
f1 = i2==f2;
f3 = i1 + i2;
f2 = i1 && f2;
}
