main()
{
	int a=10, i , b=10,e=5, f=2, g=3;
	float c=0.3,d;
	int h = (a + b) * g / ((e - f) > (a - b));
	for(i=-a;i<b;i++)
	{
		c= -(c * b);
		a++;
	}
	
	
}
