main()
{	
	int a = 1;
	int b = 2;
	int c = 3;
	float d;
d=a+b;
d=a-b;
d=b*c;
d=b/c;
			
}
