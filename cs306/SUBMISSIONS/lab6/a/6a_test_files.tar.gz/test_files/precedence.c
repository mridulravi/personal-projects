main()
{
	float a;
	float b;
	float c;
	float d;

	a = 10;
	b = 5;
	c = 2;
	d = a*b+c;	
}
