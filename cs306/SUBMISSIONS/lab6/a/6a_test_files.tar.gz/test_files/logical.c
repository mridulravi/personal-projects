main()
{
int i1, i2, i3;
float f1, f2, f3;
i1 = f1 && f2;
}
