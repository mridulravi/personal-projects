main()
{
int i1, i2, i3, i4;
float f1, f2, f3, f4;
int a, b, c, d;
a = (i1+f1) - f1*f2*i2/(i4*f4);

b = (i1/i2/f2) * f1*i3+i3-f2;

c = i1/f1/(i3*f3+i2-f1);

d = i3*f2-f3+f4-i2; 

}
