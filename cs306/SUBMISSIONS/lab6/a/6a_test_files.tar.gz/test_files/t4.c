main()
{
	int a,b;
	a=a>!b<-b>!a>-b;
}
