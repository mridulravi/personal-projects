main()
{
	int a,b,c=a-1;
	if(a+b)
	if(a-1.2)
	if(c>3.2)
	a+1;
}
