main()
{
	int a=1, b=2, c=3, e=4, f=5;
	float d=0.3;
	if(b>1)
	{
		d=d+c/a;
		a+=b;
	}
	else if(a >= b + c > d > e * d / a)
	{
		a++;
		b=-a+c;
	}


}

