
main()
{
	int a;
	int b;
	int c;
	int d;
	a=5;
	b=-a;
	d=a+2;
	c=a+b;
	c=a-b;
	c=a*b;
	c=a/b;
	
		
}
