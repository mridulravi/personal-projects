main()
{
float f1;
int i1;
for(f1=2.53;f1<5;f1=f1+1)
	{
	i1=i1+i1;
	}
}
