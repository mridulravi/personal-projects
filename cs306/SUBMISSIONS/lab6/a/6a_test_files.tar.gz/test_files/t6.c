main()
{
	int a,b,c;
	a=a+b-c/!a!=3-b/a;
}
