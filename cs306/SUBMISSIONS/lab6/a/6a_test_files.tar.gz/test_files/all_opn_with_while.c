
main()
{
	int i=1,a,b,d;
	
	

do{

i=i+1;
d=a+b;
d=a-b;
d=a/b;
d=a*b;
	
}while(i<6);

}
