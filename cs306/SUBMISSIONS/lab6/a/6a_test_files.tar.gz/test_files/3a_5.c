main()
{
	float x;
	float y;
	float z;
	x = 5.5;
  	y = 1.1;
	z=x+y*-z;
	z=x+y-x;
}
