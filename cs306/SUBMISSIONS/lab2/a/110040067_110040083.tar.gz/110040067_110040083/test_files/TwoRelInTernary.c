main()
{
	int a = 4;
	int b = 3;
	int c = 2;
	int d = 10;

	a = b > c > d?10:11;
}
