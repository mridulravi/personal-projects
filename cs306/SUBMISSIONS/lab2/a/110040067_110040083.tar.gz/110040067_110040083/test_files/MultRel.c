main()
{
	int a = 3;
	int b = 4;
	int c = 5;
	int d = 6;
	int e = 7;
	int f = 8;

	a = 8 > c <= e == d != f;
}
