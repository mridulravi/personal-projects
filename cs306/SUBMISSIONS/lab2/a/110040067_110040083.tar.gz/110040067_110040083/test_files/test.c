main()
{	
	int a = 4;
	int b = 3;
	int c = 3;

	if (c > (a > b)?0:21)
		a = 6;
	else
		b = 6;
}
