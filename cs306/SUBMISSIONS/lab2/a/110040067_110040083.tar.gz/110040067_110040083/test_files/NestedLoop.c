main()
{
	int a = 3;
	int i = 4;

	for (; a < 10; a = 4)
	{
		while (i != 8)
			i = 4;

		i = 4;
	}
}
