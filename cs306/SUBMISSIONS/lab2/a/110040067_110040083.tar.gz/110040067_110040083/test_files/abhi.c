main()
{
	int a, b, j, c=0;
	b=a;

	if(c){
		b=c;
	}
	else{
		b=10;	
	}
	for(j=0;j<10;)
	{
		b=1;
	}
	c= a>b?2:1;
	if(c){
		b=100;
	}
	return ;
}
