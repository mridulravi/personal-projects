main()
{
	for(;;)
	{
	}
}
