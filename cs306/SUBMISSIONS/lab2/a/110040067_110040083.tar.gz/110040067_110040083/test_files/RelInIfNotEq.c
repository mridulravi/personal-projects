main()
{
	int a = 3, b = 5;
	int c = 4;

	if (a > b != (!a))
	{
		a = 4;
		b = a > b >= c;
		c = c != b < a;
	}
}
