1) Abhishek Gupta 110040067
2) Abhilash Gupta 110050058
3) Dhanesh Kumar 110050021
4) Mridul Ravi Jain 110040083


NOTE: Google Calendar will be displayed only when connected to internet.

Our Screen Design has following interfaces:

Home:

1) The Home interface can be opened by home.html file. This will be the main interface which is visible to the user on first time access. 
   User does not need to login to view this interface.
2) It contains a calender which shows all the scheduled events and past events. On clicking the events in the calender more details about
   the events will be shown in the central part of screen(titled Upcoming events currently).
3) The left part contains the interface to run the queries. 
4) The central part of screen will show the upcoming events in the next few days. This part is also used to print the results of all the 
   queries. 
5) The user can switch tabs to specific categorey: Cultural, Sports, Technical, Academic. These tabs have the same interface as Home but
   show everything(queries/results/events/calender) corresponding to that categorey.
6) Apart from all this user can also run some advanced queries listed under 'More'
   
Student:

1) This has all the features of Home interface + additional features(under 'Interests') to 
	(i)   Join clubs
	(ii)  Like Sports
	(iii) Like Cultural activities
	(iv)  Like Technical activities
	
2) To enter this interface user has to login with his Roll No and Password. However, currently we are submitting only the screen design
	and therefore login doesn't work. To view this interface open student.html file. 
	
Admin:

1) This has all the features of Student interface + additional features(under 'Admin') to 
   (i)   Schedule event
   (ii)  Change details of an event
   (iii) Send reminder mails

