CS-377 LAB ASSIGNMENT 5
###############################################################

Abhishek Gupta 		110040067
Mridul Ravi Jain 	110040083
################################################################


This is our final submission for Lab Assignment-5.

We have implemented :
1) Multiprogramming Scheduler
   
   In file - multiprogramming.cpp
   
2) Time-sharing scheduler using simple round robin scheduling
   
   In file - time_sharing.cpp
   
3) Multi-level scheduler with promotions and demotions

   In file - multi_level.cpp

##################################################################

Commands to compile and run the program are:

g++ -o multi_programming multi_programming.cpp
g++ -o time_sharing time_sharing.cpp
g++ -o multi_level multi_level.cpp
./multi_programming
./time_sharing
./multi_level


##################################################################
