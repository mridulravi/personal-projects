extern char a[5];
