/******
File to hold random declarations that don't seem to belong anywhere else
*******/

#include "Event.h"
using namespace std;

ostream & operator << (ostream& ostr, const Event& e);
