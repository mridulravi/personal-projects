#include<stdio.h>
#include<stdlib.h>
#include<string.h>

char * array;

void func(char * input) {
	long * ret;
	int a = strlen(input);
	array = (char *) malloc(a+1);
	strcpy(array, input);
	ret = (long)&ret +80;
	(*ret) = (long)array;
}

void main(int argc, char*argv[]){
	printf("%d\n",argc);
	printf("%d\n",strlen(argv[1]));
	func(argv[1]);
}

// echo -e "`perl -e 'print "\x61"'`"
