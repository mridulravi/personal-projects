void fun(){
	int x=10;
}

int main(){
	fun();
}
