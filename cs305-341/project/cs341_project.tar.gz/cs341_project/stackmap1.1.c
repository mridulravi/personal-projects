int main(){
	int x = 0;
	int y= 5;
}


// if we declare even 1 local var, sp will move up by min 16 bytes.
