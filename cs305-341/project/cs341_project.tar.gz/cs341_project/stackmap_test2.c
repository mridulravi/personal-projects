#include<stdio.h>

void fun1(int a, int b){
	int w;
	w=a;
}

int main(){
	int x,y,z;
	x=10;
	y=5;
	z=1;
	fun1(y,z);
}
