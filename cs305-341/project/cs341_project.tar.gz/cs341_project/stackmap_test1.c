#include<stdio.h>

int main(){
	int x;
	x=10;
}
