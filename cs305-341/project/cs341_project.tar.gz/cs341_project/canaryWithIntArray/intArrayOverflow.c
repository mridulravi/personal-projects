#include<stdio.h>

void fun(){
	int a[10];
	int n;
	scanf("%d", &n);
	a[n] = 1002;
	
}

int main(){
	int x;
	x = 0;
	fun();
}
