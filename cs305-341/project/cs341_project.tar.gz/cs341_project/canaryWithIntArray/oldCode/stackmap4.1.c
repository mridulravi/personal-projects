// check if canary comes into picture for int array
void fun1(int a, int b){
	int arr1[10];
}

int main(){
	int y,z;
	y=5;
	z=1;
	fun1(y,z);
} 

// canary not there.
