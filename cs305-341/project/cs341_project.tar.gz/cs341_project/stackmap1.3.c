void fun(){
	
}

int main(){
	int x=10;
	fun();
}
