110040083
mridul ravi jain

For part 1 enter 3 values and the program will print the result.

For part 2 enter 5 values and the program will print the final result. It does not print the sequences, parameters and the return values.