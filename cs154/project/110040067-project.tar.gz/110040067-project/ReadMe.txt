Project Group

1)Sahil Jindal         110020043
2)Abhishek Gupta       110040067
3)Mridul Ravi Jain     110040083

Project:-
We have implemented a game whose name is "Missile Command" but with modifications. Here user's aim will be to destroy the city using the missiles. There is an anti-missile-gun which will defend the city by firing anti-missiles which will destroy the missiles.The user has to destroy the city using a fixed no of missiles, the no of missiles remaining is shown at the top(using a gauge and also through a message column named "missiles left").

Source file:-
Missile_Command.ss:- This is our only source file and is present in the Code directory.

Instructions For Running the program:-
1)Run the program using ctrl-R.
2)A window will open which will have option for selecting the level of difficulty, an exit button and a start button which will start the game.
3)The basic aim of the game is to destroy the buildings by firing the missiles from the missile launchpads.
4)To fire a missile, you have to select one of the launchpads on the top and then click anywhere inside the frame(in order to decide the direction of the missile).
5)The anti-missile-gun tries to protect the city by firing anti-missiles which would destroy the missiles.
6)There is a restart button on the top right of the frame which will take us to the first(starting) window.
7)If you lose the game, then a dialog box will appear which will show the message that you have lost and will contain a button "play again" which will take us back to the starting window.
8)If you win the game, then a dialog box will appear which will show the message that you have won and will contain a button "play again" which will take us back to the starting window.
9)After exiting the program also the process is not killed so use ctrl-K to stop the process.
